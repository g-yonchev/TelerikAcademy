﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WarMachines.Machines
{
    public static class ValidatorNullException<T> 
    {
        public static void ValidateProperty<T>(T value)
        {
            if (value == (dynamic)null)
            {
                throw new ArgumentNullException();
            }
        }
    }
}
