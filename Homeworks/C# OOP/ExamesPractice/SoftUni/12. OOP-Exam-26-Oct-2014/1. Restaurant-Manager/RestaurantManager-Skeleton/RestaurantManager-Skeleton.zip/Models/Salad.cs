﻿using RestaurantManager.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantManager.Models
{
    public class Salad : Meal, ISalad, IMeal, IRecipe
    {
        public Salad(string name, decimal price, int calories, int quantityPerServing, int timeToPrepare, bool containsPasta)
            : base(name,price,calories,quantityPerServing,timeToPrepare)
        {
            this.IsVegan = true;
            this.ContainsPasta = containsPasta;
        }
        public bool ContainsPasta { get; set; }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder();

            result.Append(base.ToString());
            result.Append(string.Format("Contains pasta: {0}", this.ContainsPasta ? "yes" : "no"));

            return result.ToString();
        }
    }
}
